import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "my_project.settings")
django.setup()

from product.models import Product
from django.contrib.auth.models import User

def seed_data():
    try:
        user = User.objects.get(username='admin')
        user.set_password('admin')
        user.is_active = True
        user.is_staff = True
        user.is_superuser = True
        user.save()
        print("Updated 'admin' user and set to active")
    except User.DoesNotExist:
        user = User.objects.create_superuser('admin', 'admin@example.com', 'admin')
        user.is_active = True
        user.save()
        print("Created new 'admin' user with password 'admin'")

    # Delete all existing products
    Product.objects.all().delete()

    products = [
        {
            "name": "Erkaklar uchun Premium Kostyum (Grey)",
            "brand": "Gucci",
            "category": "Erkaklar kiyimi",
            "description": "Erkaklar uchun premium sifatli, nafis va zamonaviy kostyum. Katta tadbirlar, to'y va ofis uchun mukammal tanlov.",
            "price": "1200000.00",
            "old_price": "1500000.00",
            "stock": 100,
            "min_order_quantity": 5,
            "color": "Kulrang",
            "size": "4XL",
            "season": "Kuz",
            "material": "Paxta",
            "country_of_origin": "Italiya",
            "image": "mens_suit.png",
        },
        {
            "name": "Ayollar uchun Elegant Oqshom Ko'ylagi (Qizil)",
            "brand": "Prada",
            "category": "Ayollar kiyimi",
            "description": "Yuqori sifatli materialdan ishlangan oqshom ko'ylagi. Dizaynerlik ishi, chiroyli bejirim ko'rinish beradi.",
            "price": "950000.00",
            "old_price": "1200000.00",
            "stock": 50,
            "min_order_quantity": 3,
            "color": "Qizil",
            "size": "36",
            "season": "Yoz",
            "material": "Ipak",
            "country_of_origin": "Fransiya",
            "image": "womens_dress.png",
        },
        {
            "name": "Erkaklar uchun Casual T-Shirt (Navy Blue)",
            "brand": "Nike",
            "category": "Erkaklar kiyimi",
            "description": "100% toza paxtadan ishlangan, har kunlik qulay kiyish uchun mo'ljallangan yozgi futbolka.",
            "price": "150000.00",
            "old_price": "200000.00",
            "stock": 500,
            "min_order_quantity": 20,
            "color": "To'q ko'k",
            "size": "M/L",
            "season": "Yoz",
            "material": "Paxta",
            "country_of_origin": "Turkiya",
            "image": "casual_tshirt.png",
        },
        {
            "name": "Ayollar uchun Qishki Issiq Kurtka (Beige)",
            "brand": "Adidas",
            "category": "Ayollar kiyimi",
            "description": "Sovuq kunlarda issiq saqlash uchun mo'ljallangan zamonaviy qishki kurtka. Suv o'tkazmaydigan sirtga ega.",
            "price": "850000.00",
            "old_price": "1000000.00",
            "stock": 150,
            "min_order_quantity": 10,
            "color": "Bej",
            "size": "38",
            "season": "Qish",
            "material": "Polyester",
            "country_of_origin": "Xitoy",
            "image": "winter_jacket.png",
        },
        {
            "name": "Erkaklar uchun Premium Jinsi shim (Dark Blue)",
            "brand": "Levi's",
            "category": "Erkaklar kiyimi",
            "description": "Klassik qora-ko'k jinsi shim. Kundalik kiyish uchun qulay va chidamli.",
            "price": "450000.00",
            "old_price": "550000.00",
            "stock": 200,
            "min_order_quantity": 10,
            "color": "To'q ko'k",
            "size": "32/34",
            "season": "Barcha mavsum",
            "material": "Denim",
            "country_of_origin": "Turkiya",
            "image": "mens_jeans.png",
        },
        {
            "name": "Ayollar uchun Midi Yubka (Black)",
            "brand": "Zara",
            "category": "Ayollar kiyimi",
            "description": "Elegant qora midi yubka. Ofis va maxsus uchrashuvlar uchun mukammal.",
            "price": "350000.00",
            "old_price": "450000.00",
            "stock": 100,
            "min_order_quantity": 5,
            "color": "Qora",
            "size": "M",
            "season": "Bahor",
            "material": "Polyester",
            "country_of_origin": "Ispaniya",
            "image": "womens_skirt.png",
        },
        {
            "name": "Erkaklar uchun Klassik Oq Ko'ylak",
            "brand": "Hugo Boss",
            "category": "Erkaklar kiyimi",
            "description": "Biznes uchrashuvlar uchun oq ko'ylak. Yuqori sifatli paxta.",
            "price": "600000.00",
            "old_price": "800000.00",
            "stock": 150,
            "min_order_quantity": 10,
            "color": "Oq",
            "size": "L",
            "season": "Barcha mavsum",
            "material": "Paxta",
            "country_of_origin": "Italiya",
            "image": "mens_shirt.png",
        },
        {
            "name": "Ayollar uchun Ipak Bluzka (Emerald Green)",
            "brand": "Mango",
            "category": "Ayollar kiyimi",
            "description": "Zumrad yashil rangli ipak bluzka. Juda yengil va teriga yoqimli.",
            "price": "500000.00",
            "old_price": "650000.00",
            "stock": 80,
            "min_order_quantity": 4,
            "color": "Zumrad yashil",
            "size": "S",
            "season": "Yoz",
            "material": "Ipak",
            "country_of_origin": "Fransiya",
            "image": "womens_blouse.png",
        },
        {
            "name": "Erkaklar uchun Qora Hoodie",
            "brand": "Puma",
            "category": "Erkaklar kiyimi",
            "description": "Sport va kundalik hayot uchun qulay qora hudi. Qalin paxta matosidan.",
            "price": "400000.00",
            "old_price": "500000.00",
            "stock": 300,
            "min_order_quantity": 15,
            "color": "Qora",
            "size": "XL",
            "season": "Kuz",
            "material": "Paxta/Fleece",
            "country_of_origin": "Vyetnam",
            "image": "mens_hoodie.png",
        },
        {
            "name": "Ayollar uchun Jun Trench Palto (Camel)",
            "brand": "Burberry",
            "category": "Ayollar kiyimi",
            "description": "Kuzgi salqin kunlar uchun lyuks darajadagi jun palto.",
            "price": "2500000.00",
            "old_price": "3000000.00",
            "stock": 40,
            "min_order_quantity": 2,
            "color": "Tuyarang (Camel)",
            "size": "M",
            "season": "Kuz",
            "material": "Jun",
            "country_of_origin": "Buyuk Britaniya",
            "image": "womens_coat.png",
        }
    ]

    for p_data in products:
        Product.objects.create(**p_data)
        
    print("Successfully seeded clothing products!")

if __name__ == "__main__":
    seed_data()
