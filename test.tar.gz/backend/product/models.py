from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=200, blank=False, null=False)
    category = models.CharField(max_length=100, blank=True, null=True, help_text="Masalan: Erkaklar kiyimi, Ayollar kiyimi, Bolalar kiyimi")
    brand = models.CharField(max_length=100, blank=True, null=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    old_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    stock = models.IntegerField(default=0)
    image = models.ImageField(null=True, blank=True)
    rating = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True, default=0)
    numReviews = models.IntegerField(null=True, blank=True, default=0)
    min_order_quantity = models.IntegerField(default=1, help_text="Ulgurji savdo uchun minimal buyurtma soni")
    
    # Advanced Filtering Fields
    color = models.CharField(max_length=50, blank=True, null=True)
    size = models.CharField(max_length=50, blank=True, null=True)
    season = models.CharField(max_length=50, blank=True, null=True)
    material = models.CharField(max_length=100, blank=True, null=True)
    country_of_origin = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.name